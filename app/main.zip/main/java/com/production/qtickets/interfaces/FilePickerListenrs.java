package com.production.qtickets.interfaces;

public interface FilePickerListenrs {
    void onGetImage(String imagename);
}
