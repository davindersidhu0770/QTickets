package com.production.qtickets.interfaces;

/**
 * Created by comp on 12/28/2015.
 */
public interface OnLoadMoreListener {
    void onLoadMore();
}
