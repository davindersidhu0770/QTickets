package com.production.qtickets.utils;


import android.view.View;

public interface OnDateSelectListener<T>{

    void onClickDate(View v , String s);

}
