package com.production.qtickets.eventQT5;

public interface CategoryItemClickListener {
    void onClick(int position,String value,String catname);
}