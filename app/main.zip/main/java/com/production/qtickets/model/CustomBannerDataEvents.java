package com.production.qtickets.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CustomBannerDataEvents {

    public String imagepath;
    public String id;
    public String imagetype;
    public String name;
    public String redirectLink;
    public String duration;
    public String censorRating;
    public boolean isWebView;
    public String lattitude ;
    public String longitude;
    public String venue;




}
