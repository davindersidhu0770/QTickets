package com.production.qtickets.model;

public class CarouselBannerData {
    public int sn;
    public String banner;
    public int eventId;
    public String eventTitle;
    public String venue;
    public String address;
    public String latitude;
    public String longitude;
    public boolean isWebView;
    public String webViewUrl;
}
