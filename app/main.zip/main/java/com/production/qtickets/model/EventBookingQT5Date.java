package com.production.qtickets.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EventBookingQT5Date {
    @SerializedName("id")
    @Expose
    public int id = 0;
    @SerializedName("date")
    @Expose
    public String date = "";



}
