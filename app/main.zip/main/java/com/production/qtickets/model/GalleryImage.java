package com.production.qtickets.model;

public class GalleryImage {
    public String image = "";
}
