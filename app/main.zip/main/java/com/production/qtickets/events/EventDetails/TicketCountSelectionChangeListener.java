package com.production.qtickets.events.EventDetails;

public interface TicketCountSelectionChangeListener {
    void onTicketCountChanged(final EventTicket pEventTicketCost);
}
