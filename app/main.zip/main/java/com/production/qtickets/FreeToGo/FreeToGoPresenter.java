package com.production.qtickets.FreeToGo;

public class FreeToGoPresenter implements FreeToGoContracter.Presenter {
    @Override
    public void attachView(FreeToGoContracter.View view) {

    }

    @Override
    public void detach() {

    }
}
